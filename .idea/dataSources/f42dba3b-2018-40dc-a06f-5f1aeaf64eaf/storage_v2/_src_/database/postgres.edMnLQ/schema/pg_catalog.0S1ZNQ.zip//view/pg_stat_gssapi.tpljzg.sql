create view pg_stat_gssapi(pid, gss_authenticated, principal, encrypted) as
SELECT s.pid,
       s.gss_auth  AS gss_authenticated,
       s.gss_princ AS principal,
       s.gss_enc   AS encrypted
FROM pg_stat_get_activity(NULL::integer) s(datid, pid, usesysid, application_name, state, query, wait_event_type,
                                           wait_event, xact_start, query_start, backend_start, state_change,
                                           client_addr, client_hostname, client_port, backend_xid, backend_xmin,
                                           backend_type, ssl, sslversion, sslcipher, sslbits, sslcompression,
                                           ssl_client_dn, ssl_client_serial, ssl_issuer_dn, gss_auth, gss_princ,
                                           gss_enc, leader_pid)
WHERE s.client_port IS NOT NULL;

alter table pg_stat_gssapi
    owner to postgres;

grant select on pg_stat_gssapi to public;

